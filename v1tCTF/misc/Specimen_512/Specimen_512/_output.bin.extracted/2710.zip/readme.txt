This is a DNA Archive payload. Life finds a flag.
